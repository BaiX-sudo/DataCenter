regsvr32 "%~dp0bdzshl.x64.dll"
exit /b
